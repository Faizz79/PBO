/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectbangundatar2;

/**
 *
 * @author hp
 */
public class Segitiga {
    double luas (int a, int b){
        return(0.5*a*b);
    }
    
    double luas (int a, double b){
        return(0.5*a*b);
    }
    
    double luas (double a, int b){
        return(0.5*a*b);
    }
    
    double luas (double a, double b){
        return(0.5*a*b);
    }
    
    double keliling (int a, int b){
        return(a*3);
    }
    
    double keliling (int a, double b){
        return(a*3);
    }
    
    double keliling (double a,int b ){
        return(a*3);
    }
    
    double keliling (double a,double b ){
        return(a*3);
    }
    
    
    
}
