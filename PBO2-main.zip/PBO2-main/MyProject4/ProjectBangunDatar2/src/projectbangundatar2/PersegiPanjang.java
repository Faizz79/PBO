/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectbangundatar2;

/**
 *
 * @author hp
 */
public class PersegiPanjang {
    int luas (int a, int b){
        return(a*b);
    }
    
    double luas (double a, int b){
        return(a*b);
    }
    
    double luas (int a, double b){
        return(a*b);
    }
    
    double luas (double a, double b){
        return (a*b);
    }
    
    //keliling
    int keliling (int a, int b){
        return (a*a+b*b);
    }
    
    double keliling (double a, int b){
        return(a*a+b*b);
    }
    
    double keliling (int a, double b){
        return(a*a+b*b);
    }
    
    double keliling (double a, double b){
        return (a*a+b*b);
    }
    
}
