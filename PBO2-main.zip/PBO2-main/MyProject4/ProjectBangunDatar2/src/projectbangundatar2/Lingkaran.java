/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectbangundatar2;

/**
 *
 * @author hp
 */
public class Lingkaran {
    double luas(int a){
      return(a*a*3.14);
    }
    
    double luas(double a){
        return(a*a*3.14);
    }
    
    double keliling(int a){
        return(a*2*3.14);
    }
    
    double keliling(double a){
        return(a*2*3.14);
    }
    
}
