/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectbangundatar2;

/**
 *
 * @author hp
 */
public class Persegi {
    double luas(double a){
        return(a*2);
    }
    
    int luas(int a){
        return(a*2);
    }
    
    double keliling(double a){
        return(a*a*a*a);
    }
    
    int keliling(int a){
        return(a*a*a*a);
    }
    
}
