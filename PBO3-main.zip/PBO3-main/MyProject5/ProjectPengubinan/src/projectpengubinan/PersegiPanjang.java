/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectpengubinan;

/**
 *
 * @author hp
 */
public class PersegiPanjang {
    
    // method untuk mengalikan dua bilangan a dan b
    static int perkalian(int a, int b){
        int hasil = a * b;
        return hasil;
    }
    
    // method
    int hitungLuas(int panjang, int lebar){
        int luas = perkalian(panjang, lebar);
        return luas;
    }
}